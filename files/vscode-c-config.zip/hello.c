#include <stdio.h>

int main(void)
{
    printf("Hello, 电控组！\n");
    printf("如果你能看到这行字，说明 VS Code + MinGW 已经配好了。\n");
    return 0;
}
